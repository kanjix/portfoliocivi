import { Component, OnInit } from '@angular/core';
import { NgIf, NgForOf, NgStyle } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Project } from '../../models/project.model';
import { ProjectsService } from '../../services/projects.service';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [NgIf, NgForOf, NgStyle, RouterLink],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
  topProjects: Project[] = [];
  loading = true;
  currentIndex = 0;

  constructor(private projectsService: ProjectsService) {}

  ngOnInit(): void {
    this.projectsService.getProjects().subscribe({
      next: (projects: Project[]) => {
        // Берём первые 4-5 проектов для обзора
        this.topProjects = projects.slice(0, 5);
        this.loading = false;
        console.log('Loaded projects:', this.topProjects);
      },
      error: (err: any) => {
        console.error('Projects load error:', err);
        this.loading = false;
      },
    });
  }

  nextProject(): void {
    if (!this.topProjects.length) return;
    this.currentIndex = (this.currentIndex + 1) % this.topProjects.length;
  }

  prevProject(): void {
    if (!this.topProjects.length) return;
    this.currentIndex =
      (this.currentIndex - 1 + this.topProjects.length) %
      this.topProjects.length;
  }

  getCardStyle(index: number): { [key: string]: string | number } {
    const total = this.topProjects.length;
    if (!total) return {};

    let offset = index - this.currentIndex;

    // Чтобы соседние карточки не прыгали через всю стопку
    if (offset > total / 2) {
      offset -= total;
    } else if (offset < -total / 2) {
      offset += total;
    }

    const depth = Math.abs(offset);
    const translateX = offset * 26; // Расстояние между карточками
    const translateY = depth * 10;
    const scale = 1 - depth * 0.06;
    const rotate = offset * 2; // Лёгкий поворот
    const opacity = depth > 2 ? 0 : 1 - depth * 0.15;
    const zIndex = 10 - depth;

    return {
      transform: `translateX(${translateX}px) translateY(${translateY}px) scale(${scale}) rotate(${rotate}deg)`,
      opacity: opacity.toString(),
      zIndex: zIndex,
    };
  }
}
