import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [RouterLink, RouterLinkActive],
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent {
  whatsappNumber = '77001234567'; // замени на свой
  email = 'youremail@example.com';

  get whatsappLink(): string {
    return `https://wa.me/${this.whatsappNumber}`;
  }

  get emailLink(): string {
    return `mailto:${this.email}`;
  }
}
